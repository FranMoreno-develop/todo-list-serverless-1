import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='fjmoreno',
    application_name='todo-list-serverless',
    app_uid='YRQnTfDLcBltSD4slQ',
    org_uid='6418bdfb-8aa2-4909-b1ab-648f883c9b63',
    deployment_uid='5c7db0d8-6a41-4b20-8ceb-0d2326c9ffe9',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
